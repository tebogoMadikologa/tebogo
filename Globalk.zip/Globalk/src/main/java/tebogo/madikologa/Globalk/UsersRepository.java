package tebogo.madikologa.Globalk;

import io.tebogo.madikologa.Globalk.models.Users;
import org.springframework.data.mongodb.repository.MongoRepository;
import models.Users;

public interface UsersRepository extends MongoRepository<Users, String> {
    Users findByUsername(String username);
}