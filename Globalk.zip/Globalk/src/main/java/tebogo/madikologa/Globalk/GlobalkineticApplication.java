package tebogo.madikologa.Globalk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlobalkineticApplication {

	public static void main(String[] args)
	{
		SpringApplication.run(GlobalkineticApplication.class, args);



	}
}
